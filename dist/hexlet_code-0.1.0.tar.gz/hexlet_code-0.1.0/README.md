### Hexlet tests and linter status:
[![Actions Status](https://github.com/Decameron87/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/Decameron87/python-project-lvl1/actions)
<a
href="http://codeclimate.com/github/Decameron87/python-project-lvl1/maintainability"><img
srs="http://api.cpdeclimat.com/v1/badges/c17f1ebeccee71977935/maintainability" /></a>
