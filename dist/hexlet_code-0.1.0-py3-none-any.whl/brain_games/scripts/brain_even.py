#!/usr/bin/env python3
from brain_games.games.parity_check import parity_check
import prompt


def main():
	parity_check()
	
	
if __name__ == '__main__':
    main()
